var win = 0; var cha = 0; var pn; var cnn; var vss; var spl; var a; var p = new Array(); var r = new Array(); var c; var r0; var r1; var r2; var r3; var r4; var r5  
window.onload = function(){
    a = document.getElementById("tex");

}  






// 버튼동작시
function ice(){
    bon = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45];  // 배열 1~45
    bpp = bon
    cnn = 45; win = 0;cha = 0;        // 랜덤 변수 뼈대
// 플레이어가 정한 숫자 6자리
r = [0,0,0,0,0,0]; 

for(var d=0; d<=5; d=d+1){
    spl = bpp.splice(Math.floor(Math.random()*cnn), 1);  // 랜덤으로 변수를 뽑아서 splice로 변수 번째의 숫자를 기준해서 찢는다
    r[d] = spl// 추출한 숫자를 저장
    cnn=cnn-1}





// 컴퓨터 랜덤 돌리기
p = [0,0,0,0,0,0,0]
for(c=0; c<=6; c=c+1){
    spl = bon.splice(Math.floor(Math.random()*cnn), 1);  // 랜덤으로 변수를 뽑아서 splice로 변수 번째의 숫자를 기준해서 찢는다
    p[c] = spl// 추출한 숫자를 저장
    cnn=cnn-1}
    // 검수 및 정답확인
for(i=0;i<=5; i=i+1){
    for(y=0;y<=5;y= y+1){
    if(r[i] == p[y]){
        win = win+1}}
    //보너스 번호 확인
    if(r[i]==p[6]){     
       cha = cha + 1 }}
    // 정답 출력
if(win < 3){
    vss = "꽝입니다.";
} else if(win == 3){
    vss = "5등입니다.";
} else if(win == 4){
    vss = "4등입니다.";
} else if(win == 5){
    if(cha == 1){
        vss = "2등입니다.";
    } else {
        vss = "3등입니다";}
    } else if(win == 6){
    vss = "1등입니다.";}
    // 출력
a.innerHTML = "로또 번호는 " + p[0] + ", "+ p[1] + ", "+ p[2] + ", "+ p[3]+ ", "+ p[4] + ", "+ p[5] + " 보너스 번호는" + p[6] + " 입니다. <br>"
         + "              "  + " 플레이어가 뽑은 숫자는" + r[0] + ", "+ r[1] + ", "+ r[ 2 ] + ", "+ r[ 3 ] + ", "+ r[ 4 ] + ", "+ r[5] + " 임으로 " + vss;}